<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="index.css">
    <title>Task 4</title>
</head>
<body>
    <h1>Task 4: Recipe tracker</h1>

    <a href="index.php">← Back to recipes</a>
    
    <h2>Title</h2>

    <form action="" method="POST">
        
        <input type="checkbox" id="ingredient1" name="ingredient1" checked disabled>
        <label for="ingredient1">ingredient1</label>

        <button type="submit">Save</button>
    </form>

    </body>
</html>