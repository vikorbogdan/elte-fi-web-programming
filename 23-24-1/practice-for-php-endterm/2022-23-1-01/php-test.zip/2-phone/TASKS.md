# Task 2: You've just won a phone!

- [ ] a.
- [ ] b.
- [ ] c.
- [ ] d.
- [ ] e.
- [ ] f.
- [ ] g.
- [ ] h.
