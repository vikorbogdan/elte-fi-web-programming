<?php

$users = json_decode(file_get_contents("foxes.json"), true);


if (!function_exists('str_contains')) {
    function str_contains($haystack, $needle)
    {
        return $needle !== '' && mb_strpos($haystack, $needle) !== false;
    }
}

$keyword = "";
if (isset($_GET["search"])) {
    $keyword = $_GET["search"];
}

$filtered_users = [];
foreach ($users as $user) {
    if (str_contains(strtolower($user["name"]), strtolower($keyword))) {
        $filtered_users[] = $user;
    }
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FaceVuk</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <nav>
        <a href="?">
            <h1>FaceVuk</h1>
        </a>
        <div style="margin-right: 20px;">
            <a style="color: white;" href="login.php">
                Register
            </a>
            <a style="color: white;" href="login.php">
                Log In
            </a>
        </div>
        <form method="get">
            <input type="text" name="search" id="search">
            <button type="submit">
                <img src="./search-icon.svg" alt="Search">
            </button>
        </form>
    </nav>
    <ul id="results">
        <?php foreach ($filtered_users as $user) : ?>
            <li>
                <img src="<?= $user["img"] ?>" alt="" />
                <h2><?= $user["name"] ?></h2>
            </li>
        <?php endforeach; ?>
    </ul>
</body>

</html>